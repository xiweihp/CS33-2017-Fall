
int int_shifts_are_arithmetic()
{
	int x = -1;
	return ((x >> 1) == x);
}
